# Implementation & Release Report: Isai Music Player v1.4.2

## Issues Addressed & Resolutions

### 1. Fix Sudden App Crash on Track Selection (Resolved)
- **Root Cause**:
  - `MediaItemMapper.kt` was previously passing raw ID3 byte arrays up to 2MB in `metadataBuilder.setArtworkData()`. When passed to `MediaController.setMediaItems()`, it exceeded Android's 1MB Binder IPC transaction buffer limit, throwing `android.os.TransactionTooLargeException` and instantly terminating the app process.
  - In `PlaybackService.kt`, `DefaultMediaNotificationProvider` was constructed without an explicit small icon drawable, throwing `IllegalArgumentException: Invalid notification (no valid small icon)` on Android 13/14/15.
  - In `PlayerController.kt`, if the media controller connection hadn't completed before the user tapped a song, commands were dropped or threw unhandled null pointers.
- **Fix Applied**:
  - Completely removed byte array IPC serialization in `MediaItemMapper.kt`. Replaced it with lightweight Content Provider URIs using dynamic `BuildConfig.APPLICATION_ID`.
  - Added `.setSmallIcon(R.drawable.ic_launcher_foreground)` to `DefaultMediaNotificationProvider.Builder`.
  - Upgraded `PlayerController.kt` to auto-reconnect asynchronously if `mediaController == null` and retry `playTrack` seamlessly.
  - Removed strict SQLite foreign keys on `QueueItemEntity` and `PlayHistoryEntity` in Room database.

### 2. Audio Track Picture Not Loading (Resolved)
- **Root Cause**:
  - In `src/App.tsx`, `raw.artPath` was completely omitted when mapping imported tracks in `__isaiOnFolderImported` and `__isaiOnTracksImported`. Thus `track.artPath` remained undefined in React state.
  - When reopening the app, `localStorage` persistence previously erased URIs for all imported tracks due to `t.isCustomFile ? '' : t.uri`.
  - If a track did not have cached art on disk, the WebView image request `/artwork?id=...` returned 404.
- **Fix Applied**:
  - Added `artPath: raw.artPath || undefined` and `nativeUri: raw.uri` to all track mappings in `src/App.tsx`.
  - Fixed `localStorage` serialization so only ephemeral browser `blob:` URLs are cleared, preserving native Android `content://` and `https://isai.local` URIs across app launches.
  - Implemented on-demand `MediaMetadataRetriever` extraction in `MainActivity.kt`'s `shouldInterceptRequest`: if an artwork file is not yet cached on disk, Android decodes the embedded picture from the track URI on the fly, writes it to disk cache, and returns it as JPEG.
  - Added graceful `onError` fallback handling in `VinylDisc.tsx`, `MiniPlayer.tsx`, and track/album list items.

### 3. Multi-Directory Folder Selection (Resolved)
- **Root Cause**:
  - In `MainActivity.kt`, querying `COLUMN_DISPLAY_NAME` on SAF root tree document URIs returned null on many device OEMs, defaulting the folder name to `"Music Folder"`.
  - In `src/App.tsx`, folder IDs were computed as `folder-${folderName.toLowerCase()}` which resolved to `folder-music_folder`.
  - When the user selected a second directory, it matched the existing folder ID and merged into it instead of creating a separate directory entry.
- **Fix Applied**:
  - In `MainActivity.kt`, used `DocumentFile.fromTreeUri(this, treeUri)?.name` with fallback to the root document ID segment.
  - Generated unique folder IDs based on tree URI hashes: `val folderId = "folder-" + Math.abs(treeUri.toString().hashCode())`.
  - Passed `folderId` directly to `window.__isaiOnFolderImported`.
  - Updated React state to isolate each folder by its unique ID, enabling multiple distinct directory cards simultaneously.

### 4. Version Bump & Release v1.4.2
- Bumped version to `1.4.2` (`versionCode = 10402`) in `android/app/build.gradle.kts` and `.github/workflows/build-apk.yml`.
- Rebuilt production web assets via `npm run build` and staged into `android/app/src/main/assets/dist/`.
- Repackaged `/public/assets/aistudio/Isai-complete-app.zip`.
- Verified compilation and lint with 0 errors.
