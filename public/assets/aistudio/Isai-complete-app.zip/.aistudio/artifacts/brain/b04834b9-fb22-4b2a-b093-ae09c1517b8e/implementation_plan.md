# Implementation & Release Report: Isai Music Player v1.4.1

## Problem Analysis & Resolutions

### 1. Crash on Selecting / Clicking a Track (Resolved)
- **Root Cause**:
  - `QueueItemEntity` and `PlayHistoryEntity` defined strict SQLite foreign key constraints referencing `TrackEntity.id` in Room.
  - When SAF or MediaStore tracks were played via the native bridge, Room threw `SQLiteConstraintException: FOREIGN KEY constraint failed`, immediately terminating the background coroutine and closing the app.
  - In `MediaItemMapper.kt`, setting `Uri.fromFile(file)` on `MediaMetadata` triggered Android's `FileUriExposedException` when building the notification on Android 7+.
- **Fix Applied**:
  - Removed strict foreign keys from `QueueItemEntity` and `PlayHistoryEntity`.
  - In `MainActivity.kt`, injected `TrackDao` and dynamically insert `track.toEntity()` on `Dispatchers.IO` before dispatching to the player.
  - Wrapped `playerController.playTrack()` and `player.setMediaItems()` in defensive `try-catch` blocks.
  - Rewrote artwork URI mapping in `MediaItemMapper.kt` to use a secure `content://com.isai.player.artwork/${track.id}` URI and direct bitmap byte payload via `metadataBuilder.setArtworkData()`, avoiding `FileUriExposedException`.

### 2. Music Picture & Metadata Not Loading (Resolved)
- **Root Cause**:
  - In `MetadataExtractor.kt`, `pfd?.close()` was called inside an inner `finally` block *before* `retriever.extractMetadata()` and `retriever.embeddedPicture`. Because `MediaMetadataRetriever` holds a reference to the active file descriptor, closing it early caused all ID3 tag and picture extraction to fail silently.
- **Fix Applied**:
  - Moved `pfd?.close()` to the outer `finally` block after all tags and embedded cover pictures are decoded.
  - Enhanced WebView request interception in `MainActivity.kt` for `/artwork?id=...` to support cached JPEGs in `cacheDir/art/`, Android 10+ `contentResolver.loadThumbnail(contentUri, Size(512, 512), null)`, and `MediaStore.Audio.Albums` content URIs.

### 3. "Can't select Downloads folder due to privacy issues" (Resolved)
- **Root Cause**:
  - Android 11+ (API 30+) Scoped Storage strictly prohibits apps from selecting the top-level `/Download` folder via `ACTION_OPEN_DOCUMENT_TREE` (SAF folder picker).
- **Fix Applied**:
  - Added native device-wide audio querying in `MainActivity.kt` via `MediaStore.Audio.Media.EXTERNAL_CONTENT_URI` (`scanAllDeviceAudio()`).
  - Added a prominent **"Scan All Songs on Phone (Including Downloads)"** button in the Add Music modal and empty state. This queries the system MediaStore with `READ_MEDIA_AUDIO` / `READ_EXTERNAL_STORAGE` permissions, instantly capturing every downloaded audio track across storage without folder restrictions.

### 4. Incorrect Opening Splash Screen Logo (Resolved)
- **Root Cause**:
  - Android 12+ (API 31+) uses system splash screen attributes prefixed with `android:`. Without `values-v31/splash.xml`, modern Android 12–15 devices ignored `windowSplashScreenAnimatedIcon` and displayed the system default or cached legacy icon.
- **Fix Applied**:
  - Created `android/app/src/main/res/values-v31/splash.xml` and `values-night-v31/splash.xml` configuring `android:windowSplashScreenAnimatedIcon` to `@drawable/ic_splash_logo` and `android:windowSplashScreenBackground` to `#000000`.
  - Regenerated all mipmap launcher icons (`mdpi`, `hdpi`, `xhdpi`, `xxhdpi`, `xxxhdpi`) and `ic_isai_logo.png` directly from `public/app-icon.png` (the official stylized orange/white Isai logo).

### 5. Build Verification & Release Automation (v1.4.1)
- Bumped app version to `1.4.1` (versionCode `10401`) in `android/app/build.gradle.kts` and `.github/workflows/build-apk.yml`.
- Re-built production web bundle via Vite (`npm run build`) and staged all assets in `android/app/src/main/assets/dist/`.
- Re-packaged `/public/assets/aistudio/Isai-complete-app.zip`.
- Successfully validated codebase with co-executed `compile_applet` and `lint_applet` with 0 errors.
